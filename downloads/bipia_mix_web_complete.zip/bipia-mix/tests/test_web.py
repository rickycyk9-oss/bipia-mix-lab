import json
import io
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from pathlib import Path

from bipia_mix.web import ExperimentApp, make_server
from bipia_mix.client import ChatClient


class WebTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        root=Path(__file__).resolve().parents[1]
        self.app=ExperimentApp(root, Path(self.tmp.name))
        self.server=make_server(self.app,0)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join();self.tmp.cleanup()

    def post(self,path,data,origin=None):
        headers={'Content-Type':'application/json','Origin':origin or self.url}
        req=urllib.request.Request(self.url+path,data=json.dumps(data).encode(),headers=headers)
        with urllib.request.urlopen(req) as r:return json.load(r)

    def test_bootstrap_and_build_real_paired_study(self):
        with urllib.request.urlopen(self.url+'/api/bootstrap') as r:initial=json.load(r)
        self.assertEqual(len(initial['cases']),6)
        reviewed=self.post('/api/approve',{'variants':initial['variants'],'reviewer':'Researcher'})
        built=self.post('/api/build',{'cases':initial['cases'],'variants':reviewed['variants'],
                                    'name':'First run','positions':['start','middle','end']})
        self.assertEqual(built['attacked'],72)
        self.assertTrue((Path(self.tmp.name)/built['study_id']/'study.jsonl').exists())

    def test_run_resume_score_and_download_do_not_save_secret(self):
        calls=[]
        class ModelHandler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                calls.append(payload)
                if 'evaluating an authorized' in payload['messages'][0]['content']:
                    evidence=json.loads(payload['messages'][1]['content'])
                    text=json.dumps({'attack_success':None if evidence['clean_control'] else False,
                                     'task_correct':True,'reason':'Local protocol test.'})
                else:text='Local protocol test answer'
                body=json.dumps({'model':'test-resolved','choices':[{'message':{'content':text},'finish_reason':'stop'}]}).encode()
                self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        model=ThreadingHTTPServer(('127.0.0.1',0),ModelHandler)
        thread=threading.Thread(target=model.serve_forever,daemon=True);thread.start()
        config={'model':'test-local','base_url':f'http://127.0.0.1:{model.server_port}/v1',
                'api_key_env':'UNSET_WEB_TEST_KEY','max_retries':0,'retry_backoff':0}
        secret='web-test-credential-never-on-disk'
        def finish(job):
            deadline=time.monotonic()+10
            while time.monotonic()<deadline:
                with urllib.request.urlopen(self.url+'/api/jobs/'+job['job_id']) as r:status=json.load(r)
                if status['status']!='running':
                    self.assertEqual(status['status'],'done',status);return status
                time.sleep(.02)
            self.fail('job did not finish')
        try:
            data=self.app.bootstrap()
            reviewed=self.post('/api/approve',{'variants':data['variants'],'reviewer':'Test'})
            built=self.post('/api/build',{'cases':data['cases'][:1],'variants':reviewed['variants'],'positions':['end']})
            payload={'study_id':built['study_id'],'config':config,'api_key':secret}
            finish(self.post('/api/run',{**payload,'max_requests':2}))
            self.assertEqual(len(calls),2)
            finish(self.post('/api/score',payload));self.assertEqual(len(calls),4)
            finish(self.post('/api/run',payload));self.assertEqual(len(calls),7)
            with urllib.request.urlopen(self.url+'/api/results/'+built['study_id']) as r:stale=json.load(r)
            self.assertIsNone(stale['summary']);self.assertTrue(stale['summary_stale'])
            finish(self.post('/api/run',payload));self.assertEqual(len(calls),7)
            finish(self.post('/api/score',payload));self.assertEqual(len(calls),10)
            with urllib.request.urlopen(self.url+'/api/results/'+built['study_id']) as r:result=json.load(r)
            self.assertEqual(len(result['responses']),5);self.assertIsNotNone(result['summary'])
            with urllib.request.urlopen(self.url+'/api/download/'+built['study_id']) as r:archive=r.read()
            with zipfile.ZipFile(io.BytesIO(archive)) as z:
                self.assertIn('report/summary.json',z.namelist())
                self.assertTrue(all(secret.encode() not in z.read(n) for n in z.namelist()))
        finally:model.shutdown();model.server_close();thread.join()

    def test_foreign_origin_is_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.post('/api/select',{'count':6},origin='https://attacker.example')
        self.assertEqual(caught.exception.code,403)

    def test_arbitrary_file_paths_not_served(self):
        with self.assertRaises(urllib.error.HTTPError):
            urllib.request.urlopen(self.url+'/../../README.md')

    def test_memory_api_key_not_in_public_config(self):
        client=ChatClient({'model':'example'},api_key='example-secret-not-for-disk')
        self.assertNotIn('example-secret-not-for-disk',json.dumps(client.public_config()))

    def test_bad_json_and_content_type_are_rejected(self):
        req=urllib.request.Request(self.url+'/api/select',data=b'{}',headers={'Content-Type':'text/plain','Origin':self.url})
        with self.assertRaises(urllib.error.HTTPError) as caught:urllib.request.urlopen(req)
        self.assertEqual(caught.exception.code,415)


if __name__=='__main__':unittest.main()
