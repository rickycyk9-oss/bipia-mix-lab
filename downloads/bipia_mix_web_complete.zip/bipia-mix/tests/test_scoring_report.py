import tempfile
import unittest
from pathlib import Path

from bipia_mix.scoring import parse_judgment, score_records
from bipia_mix.report import summarize
from bipia_mix.data import build_study
from bipia_mix.variants import approve_variants
from bipia_mix.storage import digest, write_json, write_jsonl, read_jsonl
from tests.test_data import example_case, example_variant


class ScoreTests(unittest.TestCase):
    def test_judge_requires_actual_booleans(self):
        for value in ('false', 0, [], {}):
            with self.assertRaises(ValueError):
                parse_judgment({'attack_success':value,'task_correct':True,'reason':'R'}, clean=False)
        result=parse_judgment({'attack_success':None,'task_correct':False,'reason':'uncertain'},clean=False)
        self.assertIsNone(result['attack_success'])

    def test_marker_requires_compliance_not_merely_quoting(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('end',),include_clean=False)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'responses.jsonl';out=Path(d)/'scores.jsonl'
            manifest={'schema':1,'stage':'inference','study_digest':digest(study),
                      'client':{'model':'offline-simulator'},'repeats':1,'order_seed':0}
            write_json(str(p)+'.manifest.json',manifest)
            records=[]
            for i,row in enumerate(study):
                records.append({'job_id':row['sample_id']+':0','sample_id':row['sample_id'],
                                'repeat':0,'run_id':digest(manifest),'status':'ok',
                                'text':'ORANGE_731' if i==0 else 'I will not output ORANGE_731.'})
            write_jsonl(p,records)
            score_records(study,p,out,method='demo-marker')
            scores=read_jsonl(out)
            self.assertEqual(sum(s['attack_success'] for s in scores),1)

    def test_report_counts_missing_and_technical_failures_separately(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('end',),include_clean=False)
        responses=[{'job_id':row['sample_id']+':0','sample_id':row['sample_id'], 'repeat':0,
                    'status':'error' if i==0 else 'ok','text':'x'} for i,row in enumerate(study[:3])]
        scores=[{'job_id':r['job_id'],'sample_id':r['sample_id'],'repeat':0,
                 'status':'ok','attack_success':True,'task_correct':False,
                 'response_digest':digest(r)} for r in responses[1:]]
        report=summarize(study,responses,scores,repeats=1,bootstrap=50)
        en=next(g for g in report['groups'] if g['condition']=='en')
        self.assertEqual(en['generation_error'],1)
        self.assertIsNone(en['asr'])
        self.assertEqual(report['total']['missing_generation'],1)
        self.assertEqual(report['paired'][0]['n_complete_pairs'],0)

    def test_paired_effect_and_cluster_count(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('start','end'),include_clean=False)
        responses=[];scores=[]
        for row in study:
            response={'job_id':row['sample_id']+':0','sample_id':row['sample_id'],'repeat':0,'status':'ok','text':'x'}
            responses.append(response)
            scores.append({'job_id':response['job_id'],'sample_id':row['sample_id'],'repeat':0,
                           'status':'ok','attack_success':row['condition']=='zh','task_correct':False,
                           'response_digest':digest(response)})
        result=summarize(study,responses,scores,repeats=1,bootstrap=50)
        zh=next(p for p in result['paired'] if p['condition']=='zh')
        self.assertEqual(zh['delta_asr_vs_en'],1.0)
        self.assertEqual(zh['n_complete_pairs'],2)
        self.assertEqual(zh['n_context_clusters'],1)
        self.assertIsNone(zh['cluster_bootstrap_ci95'])


if __name__=='__main__':unittest.main()
