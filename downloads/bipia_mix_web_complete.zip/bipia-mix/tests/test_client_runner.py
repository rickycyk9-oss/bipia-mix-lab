import json
import os
import tempfile
import threading
import unittest
import gc
import warnings
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from bipia_mix.client import ChatClient, APIError, parse_json_object
from bipia_mix.runner import run_study
from bipia_mix.storage import read_jsonl, writer_lock
from bipia_mix.data import build_study
from bipia_mix.scoring import score_records
from bipia_mix.variants import approve_variants
from tests.test_data import example_case, example_variant


class Handler(BaseHTTPRequestHandler):
    calls = []
    replies = []

    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        type(self).calls.append(body)
        status, reply = type(self).replies.pop(0)
        self.send_response(status); self.send_header('Content-Type','application/json'); self.end_headers()
        self.wfile.write(json.dumps(reply).encode())

    def log_message(self, *args):
        pass


class ClientTests(unittest.TestCase):
    def setUp(self):
        Handler.calls=[];Handler.replies=[]
        self.server=ThreadingHTTPServer(('127.0.0.1',0), Handler)
        self.thread=threading.Thread(target=self.server.serve_forever, daemon=True);self.thread.start()
        self.config={'model':'local-test','base_url':f'http://127.0.0.1:{self.server.server_port}/v1',
                     'api_key_env':None,'max_retries':1,'retry_backoff':0}

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join()

    def test_retry_429_and_preserve_payload(self):
        Handler.replies=[(429,{'error':'slow'}),(200,{'model':'resolved-model','choices':[{'message':{'content':'3 pm'}}]})]
        result=ChatClient(self.config).complete([{'role':'user','content':'When?'}])
        self.assertEqual(result['text'],'3 pm')
        self.assertEqual(len(Handler.calls),2)
        self.assertEqual(Handler.calls[0]['messages'][0]['content'],'When?')

    def test_empty_response_is_error(self):
        Handler.replies=[(200,{'choices':[{'message':{'content':''}}]})]
        with self.assertRaises(APIError):ChatClient(self.config).complete([])

    def test_structured_refusal_is_a_valid_model_response(self):
        Handler.replies=[(200,{'choices':[{'message':{'content':None,'refusal':'I cannot comply.'},'finish_reason':'stop'}]})]
        reply=ChatClient(self.config).complete([])
        self.assertEqual(reply['text'],'I cannot comply.')
        self.assertEqual(reply['response_type'],'refusal')

    def test_http_error_closes_response_resource(self):
        Handler.replies=[(400,{})]
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always',ResourceWarning)
            with self.assertRaises(APIError):ChatClient(self.config).complete([])
            gc.collect()
        self.assertFalse([w for w in caught if issubclass(w.category,ResourceWarning)])

    def test_errors_never_leak_api_key(self):
        os.environ['MIX_TEST_KEY']='secret-example-key'
        cfg=dict(self.config,api_key_env='MIX_TEST_KEY')
        Handler.replies=[(401,{'error':'secret-example-key rejected'})]
        try:
            with self.assertRaises(APIError) as caught: ChatClient(cfg).complete([])
            self.assertNotIn('secret-example-key', str(caught.exception))
            self.assertNotIn('secret-example-key',json.dumps(ChatClient(cfg).public_config()))
        finally:os.environ.pop('MIX_TEST_KEY')

    def test_resume_retries_only_failed_row_without_alignment_loss(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('end',),include_clean=False)[:2]
        Handler.replies=[(400,{}),(200,{'choices':[{'message':{'content':'first-good'}}]}),
                         (200,{'choices':[{'message':{'content':'retry-good'}}]})]
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'responses.jsonl';client=ChatClient(self.config)
            run_study(study,client,path,order_seed=0)
            first=read_jsonl(path)
            self.assertEqual([r['status'] for r in first],['error','ok'])
            run_study(study,client,path,order_seed=0)
            rows=read_jsonl(path)
            self.assertEqual(rows[0]['sample_id'], rows[2]['sample_id'])
            self.assertNotEqual(rows[1]['sample_id'], rows[2]['sample_id'])
            self.assertEqual(len(Handler.calls),3)
            with self.assertRaisesRegex(ValueError,'manifest'):
                run_study(study,ChatClient(dict(self.config,model='changed')),path,order_seed=0)

    def test_single_writer_lock(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'run.jsonl'
            with writer_lock(p):
                with self.assertRaisesRegex(ValueError,'lock'): 
                    with writer_lock(p):pass

    def test_concurrent_success_is_saved_before_earlier_slow_request(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('end',),include_clean=False)[:2]
        started=threading.Event();release=threading.Event();fast_done=threading.Event()
        slow_messages=study[0]['messages']
        class ControlledClient:
            def public_config(self):return {'model':'controlled-test'}
            def complete(self,messages):
                if messages==slow_messages:
                    started.set();release.wait(3)
                else:fast_done.set()
                return {'text':'answer','finish_reason':'stop'}
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'out.jsonl'
            thread=threading.Thread(target=lambda:run_study(study,ControlledClient(),p,workers=2,order_seed=0))
            thread.start()
            try:
                self.assertTrue(started.wait(1));self.assertTrue(fast_done.wait(1))
                deadline=time.monotonic()+.5
                while not p.exists() and time.monotonic()<deadline:time.sleep(.01)
                self.assertTrue(p.exists(),'completed fast request was not persisted')
                self.assertEqual(read_jsonl(p)[0]['sample_id'],study[1]['sample_id'])
            finally:release.set();thread.join(4)

    def test_filtered_partial_output_is_not_a_complete_response(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('end',),include_clean=False)[:1]
        Handler.replies=[(200,{'choices':[{'message':{'content':'A partial answer'},'finish_reason':'content_filter'}]})]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'filtered.jsonl'
            run_study(study,ChatClient(self.config),p)
            self.assertEqual(read_jsonl(p)[0]['status'],'filtered')

    def test_semantic_judge_http_roundtrip_and_unknown_preserved(self):
        study=build_study([example_case()],approve_variants([example_variant()],'R'),
                          middle_mode='line',positions=('end',),include_clean=False)[:1]
        judgment={'attack_success':None,'task_correct':True,'reason':'Insufficient evidence for the attack goal.'}
        Handler.replies=[(200,{'choices':[{'message':{'content':'3 pm'}}]}),
                         (200,{'choices':[{'message':{'content':json.dumps(judgment)}}]})]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'responses.jsonl';scores=Path(d)/'scores.jsonl';client=ChatClient(self.config)
            run_study(study,client,p)
            score_records(study,p,scores,client)
            row=read_jsonl(scores)[0]
            self.assertEqual(row['status'],'ok');self.assertIsNone(row['attack_success'])
            evidence=json.loads(Handler.calls[1]['messages'][1]['content'])
            self.assertEqual(evidence['original_attack'],study[0]['attack_original'])
            self.assertNotIn('condition',evidence)
            score_records(study,p,scores,client)
            self.assertEqual(len(Handler.calls),2)

    def test_json_parser_rejects_prose_and_accepts_fenced_object(self):
        self.assertEqual(parse_json_object('```json\n{"x":true}\n```'),{'x':True})
        with self.assertRaises(ValueError):parse_json_object('Explanation {"x":1}')


if __name__=='__main__':unittest.main()
