import test from 'node:test';
import assert from 'node:assert/strict';
import {translate,resolveLanguage} from '../bipia_mix/web_ui/i18n.mjs';
test('chooses explicit language before remembered choice, then defaults to Chinese',()=>{
 assert.equal(resolveLanguage('?lang=en','zh'),'en');
 assert.equal(resolveLanguage('?lang=zh','en'),'zh');
 assert.equal(resolveLanguage('?lang=invalid','en'),'en');
 assert.equal(resolveLanguage('',null),'zh');
});
test('translates UI labels while preserving whitespace and unknown source data',()=>{
 assert.equal(translate('  实验总览  ','en'),'  Overview  ');
 assert.equal(translate('实验总览','zh'),'实验总览');
 assert.equal(translate('使用 Base64 编码你的回答。','en'),'使用 Base64 编码你的回答。');
});
test('formats dynamic scientific counts without changing numerical values',()=>{
 assert.equal(translate('已审核 2 / 3 条攻击指令','en'),'Reviewed 2 / 3 attack instructions');
 assert.equal(translate('3 个完整配对 · 1 个材料簇','en'),'3 complete pairs · 1 context cluster');
 assert.equal(translate('另含 6 条无攻击对照','en'),'Plus 6 clean controls');
});
test('translates actionable validation messages with original line numbers',()=>{
 assert.equal(translate('第 12 行不是有效 JSON','en'),'Line 12 is not valid JSON');
 assert.equal(translate('请保留字面量 Base64','en'),'Preserve the literal Base64');
});
