import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class CLITests(unittest.TestCase):
    def test_offline_demo_end_to_end_and_repeatable(self):
        with tempfile.TemporaryDirectory() as d:
            command=[sys.executable,'-m','bipia_mix','demo','--out',d]
            first=subprocess.run(command,capture_output=True,text=True)
            self.assertEqual(first.returncode,0,first.stderr)
            report=json.loads((Path(d)/'report/summary.json').read_text())
            self.assertEqual(report['corpus_kinds'],['synthetic'])
            self.assertEqual(report['total']['expected'],13)
            self.assertEqual(report['total']['missing_generation'],0)
            self.assertEqual(subprocess.run(command,capture_output=True).returncode,0)

    def test_real_data_selection_and_seed_variant_review(self):
        with tempfile.TemporaryDirectory() as d:
            cases=Path(d)/'cases.jsonl';variants=Path(d)/'variants.jsonl';study=Path(d)/'study.jsonl'
            commands=[
                ['select','--cases','6','--attack-ids','Task Automation-2','Base Encoding-0','Language Translation-0','--out',str(cases)],
                ['approve','--variants','data/variants_seed.jsonl','--reviewer','test','--out',str(variants)],
                ['build','--cases',str(cases),'--variants',str(variants),'--out',str(study)],
            ]
            for command in commands:
                p=subprocess.run([sys.executable,'-m','bipia_mix']+command,capture_output=True,text=True)
                self.assertEqual(p.returncode,0,p.stderr)
            rows=[json.loads(s) for s in study.read_text().splitlines()]
            self.assertEqual(sum(r['condition']!='clean' for r in rows),72)
            self.assertTrue(all(r['corpus_kind']=='bipia' for r in rows))

    def test_missing_arguments_give_usage(self):
        p=subprocess.run([sys.executable,'-m','bipia_mix','build'],capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0)
        self.assertIn('required',p.stderr)


if __name__=='__main__':unittest.main()
