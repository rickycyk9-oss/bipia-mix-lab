# Delivery verification

Environment: Python 3.12.14 on Linux; NLTK 3.9.1.

- `python -m unittest discover -s tests -v`: 26 tests, all passed, no skipped tests.
- `python -m pip install -e . --no-deps`: editable package build/install succeeded.
- `python -m bipia_mix demo --out examples/offline_demo`: end-to-end 13-row synthetic
  demonstration generated with no missing requests/scores and no API calls.
- Official snapshot fetched from commit
  a004b69ec0dd446e0afd461d98cb5e96e120a5d0; file SHA-256 values retained.
- Real-data CLI test selects six official email/attack pairs, approves test
  fixtures, builds all 72 attacked variants and unique clean controls using Punkt.
- Local HTTP tests verify request JSON, bounded 429 retry, error sanitization,
  empty output handling, structured refusals, filtered partial output status,
  semantic-judge JSON and unknown results. No paid model endpoint was used.

Fresh-context read-only code review found three substantive issues, all fixed:

1. Translator cache reused old model settings: generation now binds a manifest to
   translator configuration and translation-prompt digest. Regression demonstrates
   mismatch rejection for changed model and prompt.
2. Parallel completed requests waited behind slow earlier requests: each completed
   future is now fsynced in completion order. Regression holds an earlier request
   open and confirms a later result is already on disk.
3. Filtered partial answers were accepted as complete: content_filter and other
   incomplete finish states now remain outside the primary valid-score denominator.
   Actual text/structured refusals remain valid model outputs.

All three regressions were observed failing before their fixes and passing after.
The complete suite was rerun after fixes. No unresolved code-review blocker was
reported. Methodological limits (human equivalence checks, short-clause switching,
judge reliability, context-only clustering) are disclosed in README.md.

Not performed: real paid-model experiment, Windows execution, large-scale throughput
measurement, human translation validation, or empirical proof of attack efficacy.


## Web console v1.1

- 32 Python tests passed, including loopback web build, run-two, resume, partial scoring, stale-report invalidation, scoring, and ZIP download against a local fake model. No cloud provider was called.
- 8 JavaScript tests passed, including paired counts, approval SHA-256 fallback, imported-summary schema validation, and sample-ID result alignment.
- Browser checked dashboard, per-attack approval state, synthetic demo, charts and sample table.
- Owner-private hosted preview is static; actual inference uses python -m bipia_mix web on localhost. Model credentials are session-only and excluded from generated configs and archives.
