# BIPIA Mix Implementation Plan

> For agentic workers: implement inline with executing-plans; use tests before code.

**Goal:** Deliver a reproducible paired English–Chinese indirect-injection toolkit.
**Architecture:** JSONL datasets and durable append-only run logs. Separate data,
language transformation, client, inference, judging, reporting and CLI modules.
**Tech stack:** Python 3.10+, standard library, optional NLTK 3.9.1.
**Spec:** docs/design.md.

## Global constraints
- Preserve original tasks, attack objectives and IDs; no real API keys in files.
- Four paired language conditions; separate clean controls and technical errors.
- Only human-reviewed variants in formal builds; no synthetic empirical claims.
- Never execute generated code. Preserve upstream attribution and source hashes.

## Review focus
Input/model changes must invalidate resume; failed calls cannot misalign rows;
changed translations invalidate approval; position/replicate correlations cannot
inflate confidence; missing or malformed judge results cannot count as failures.

## Tasks
1. Tests first: data selection, approval digest, build invariants, Punkt parity.
   Implement storage/data/variants/build. Verify full unittest suite.
2. Tests first: local HTTP retry, empty output, resume mismatches and row identity.
   Implement client and inference runner. Verify full unittest suite.
3. Tests first: strict judge schema, valid denominators, paired cluster comparison.
   Implement scoring and reporting. Verify full unittest suite.
4. Test CLI end to end; implement offline demo, Chinese documentation, example
   configurations and scripts. Run installation and bundled BIPIA smoke checks.
5. Fresh-context review, fix substantive findings with regression tests, full
   verification, package all deliverables and save the ZIP.
