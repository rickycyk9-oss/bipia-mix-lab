# BIPIA Lab web console

User requested a website to improve the validation and experiment workflow of the
existing paired English–Chinese BIPIA project. Build a focused, Chinese, responsive
research workspace with overview, editable variant review, model roles, experiment
jobs, reports and a practical local launch guide.

Decision: retain the tested Python engine and add a localhost-only stdlib HTTP
adapter. The same buildless frontend has a private hosted preview for review/import
and clearly labeled offline demonstration. Hosted preview does not receive model
keys or pretend to control the visitor's local Python process. Real runs use the
downloadable project at http://127.0.0.1:8765. API keys are memory-only; no browser
storage, JSONL, configuration export or download archive may contain a key.

Local API: select cases, approve variants using existing digest rules, build a
study, test a configured model, translate with a background job, run inference with
resume, score/report, list jobs and download run artifacts. Server binds loopback,
rejects foreign Origin/Host and non-JSON POSTs, and serves only known static assets.
No arbitrary file path, subprocess command or generated code execution endpoint.

The interface defaults to 6 real BIPIA pairs and 3 draft seed attacks. Four language
conditions and three positions remain paired. Actual ASR is never populated from
simulation without a visible synthetic-data notice. Imported results can be viewed
in the hosted preview. Manual review records reviewer identity and invalidates on
edits. Connection tests and experiments only run after an explicit user action.

Verification: tests for API contracts/security, approval changes, background job
results, JSONL import/summary; preserve all original tests. Browser QA of preview
and local console where supported, and a fresh code review before handoff.
