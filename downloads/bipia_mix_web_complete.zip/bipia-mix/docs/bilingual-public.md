# Public bilingual console

The existing static dashboard will become public on the same URL. Add a Chinese / English switch to the header, remember the choice per browser, and accept ?lang=en or ?lang=zh for shareable language links. The default stays Chinese.

Translate interface copy, field labels, accessible names, messages, modals and guides using a checked-in human-written catalog. Preserve attack text, input/output data, model names, API settings, reviewer names and exported scientific records verbatim. Switching language must not reset settings, approval, results, pending edits or background jobs.

The online site remains a browser-local workflow preview and demonstration. Actual model execution uses the downloadable localhost Python console. This change grants public page access without adding model API keys to hosting.

Implementation: add a locale module with exact UI translations and explicit dynamic-message patterns; apply it to generated UI while protecting user/data regions; add persistent header buttons and responsive English layout. Sync the locale module into the downloadable Python kit and its fixed asset allowlist. Test translation behavior and all existing Python/JS tests; browser-check all six English screens, dialogs and switching back. Then push exact source, save a version, set the explicitly requested public audience and deploy it.
