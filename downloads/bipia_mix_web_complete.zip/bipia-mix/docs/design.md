# BIPIA English–Chinese paired study

Build a complete Python 3.10+ command-line research project for the four language
conditions discussed with the user: en, zh, mixed_sentence, mixed_phrase.
Use official BIPIA text-task data and retain attack IDs, original instructions,
context hashes, split, question and reference answers. Do not replace original
attack goals with a marker in real experiments. A synthetic marker demonstration
is explicitly labeled, offline, and never represented as experimental evidence.

Chosen implementation: a lightweight independent harness, not an installation of
the upstream GPU training stack. Only NLTK 3.9.1 is needed for upstream-compatible
random sentence-boundary insertion. HTTP, JSON, CLI, tests and statistics use the
standard library. No training, generated-code execution, or external message sends.
Alternative considered: patch upstream BIPIA; rejected due to obsolete dependency
stack and output-alignment/resume problems. No user model/API preference is assumed.

Pipeline: select stratified original cases -> generate/review attack variants ->
build paired prompts and clean controls -> durable API inference -> independent
semantic judge (or demo marker rule) -> grouped and paired reports. Translation,
target and judge configurations are independent and use environment-only keys.
Default messages reproduce BIPIA system/user text templates; an explicit user-data
layout is available and is recorded. The selected middle offset is computed once
per original context using upstream Punkt logic and reused for all conditions.

Invariant: an experiment row has a stable ID over its full content. Changed input,
model config or scoring rubric cannot silently reuse earlier successes. API errors,
empty outputs and invalid judge JSON have explicit states, never ASR=0. All four
language conditions must exist for paired comparison. Bootstrap by context_id, not
by correlated variants. Human approval binds to variant content via a digest.

Completion: offline end-to-end example, real upstream import, protocol round trips
against a local HTTP server, regression tests, Chinese README, usage scripts,
source manifest and a downloadable source ZIP. Paid API experiments are user-run.
