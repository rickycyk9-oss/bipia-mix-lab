"""One durable, content-bound record per request, with safe resumption."""
from __future__ import annotations

import concurrent.futures
import random
from datetime import datetime, timezone
from pathlib import Path

from .storage import (digest, unique_index, read_json, write_json, read_jsonl,
                      append_jsonl, writer_lock)


def validate_study(study):
    unique_index(study)
    if not study:
        raise ValueError('study is empty')
    for row in study:
        expected = digest({k:v for k,v in row.items() if k!='sample_id'})
        if expected != row['sample_id']:
            raise ValueError('study sample_id does not match content; rebuild the study after editing')


def bind_manifest(output, manifest):
    path = Path(str(output)+'.manifest.json')
    if path.exists():
        if read_json(path) != manifest:
            raise ValueError('run manifest mismatch: input/model/settings changed; choose a new output file')
    else:
        if Path(output).exists() and Path(output).stat().st_size:
            raise ValueError('nonempty output has no manifest; choose a new output file')
        write_json(path, manifest)


def latest_records(path, run_id=None):
    index = {}
    for row in read_jsonl(path) if Path(path).exists() else []:
        if run_id is not None and row.get('run_id') != run_id:
            raise ValueError('record run_id differs from manifest')
        index[row['job_id']] = row
    return index


def run_study(study, client, output, repeats=1, order_seed=2023, max_requests=None,
              workers=1):
    validate_study(study)
    if repeats<1 or not 1<=workers<=16 or (max_requests is not None and max_requests<0):
        raise ValueError('invalid repeats/workers/max_requests')
    manifest = {'schema':1, 'stage':'inference', 'study_digest':digest(study),
                'client':client.public_config(), 'repeats':repeats, 'order_seed':order_seed}
    run_id = digest(manifest)
    with writer_lock(output):
        bind_manifest(output, manifest)
        previous = latest_records(output, run_id)
        jobs = [(row, repeat) for row in study for repeat in range(repeats)]
        random.Random(order_seed).shuffle(jobs)
        jobs = [(row,rep) for row,rep in jobs
                if previous.get(f'{row["sample_id"]}:{rep}',{}).get('status') not in ('ok','truncated','filtered','incomplete')]
        if max_requests is not None:
            jobs = jobs[:max_requests]

        def request(job):
            row, repeat = job
            record = {'job_id':f'{row["sample_id"]}:{repeat}', 'sample_id':row['sample_id'],
                      'repeat':repeat, 'run_id':run_id,
                      'time_utc':datetime.now(timezone.utc).isoformat()}
            try:
                result = client.complete(row['messages'])
                finish = result['finish_reason']
                status = ('truncated' if finish=='length' else 'filtered' if finish=='content_filter'
                          else 'incomplete' if finish not in (None,'stop') else 'ok')
                record.update(status=status, **result)
            except Exception as exc:
                # Only error type/APIError text is recorded; never arbitrary provider bodies.
                from .client import APIError
                record.update(status='error', error=str(exc) if isinstance(exc,APIError) else type(exc).__name__)
            return record

        processed = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(request, job) for job in jobs]
            for future in concurrent.futures.as_completed(futures):
                record = future.result()
                append_jsonl(output, record)
                processed += 1
        latest = latest_records(output, run_id)
    return {'requested_now':processed, 'ok':sum(x['status']=='ok' for x in latest.values()),
            'truncated':sum(x['status']=='truncated' for x in latest.values()),
            'filtered':sum(x['status']=='filtered' for x in latest.values()),
            'incomplete':sum(x['status']=='incomplete' for x in latest.values()),
            'error':sum(x['status']=='error' for x in latest.values()),
            'expected':len(study)*repeats, 'run_id':run_id}
