"""Paired English–Chinese experiments built from BIPIA text tasks."""

__version__ = '1.2.0'
