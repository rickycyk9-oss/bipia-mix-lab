"""OpenAI-compatible chat HTTP client; no OpenAI SDK or GPU stack required."""
from __future__ import annotations

import json
import math
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

from .storage import read_json


class APIError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def parse_json_object(text):
    text = text.strip()
    match = re.fullmatch(r'```(?:json)?\s*([\s\S]*?)\s*```', text)
    if match:
        text = match.group(1)
    obj = json.loads(text)
    if not isinstance(obj, dict):
        raise ValueError('model must return a JSON object')
    return obj


class ChatClient:
    DEFAULTS = {'base_url':'https://api.openai.com/v1', 'api_key_env':'OPENAI_API_KEY',
                'temperature':0, 'max_tokens':1024, 'token_parameter':'max_tokens',
                'timeout':90, 'max_retries':3, 'retry_backoff':1.0,
                'max_input_chars':100000, 'json_mode':False}

    def __init__(self, config, *, api_key=None):
        # Optional localhost-console credential: retained in memory, never config.
        self._api_key = api_key
        raw = read_json(config) if isinstance(config, (str, __import__('pathlib').Path)) else dict(config)
        allowed = set(self.DEFAULTS) | {'model'}
        unknown = set(raw) - allowed
        if unknown:
            raise ValueError(f'unknown model config keys: {sorted(unknown)}; API keys belong in environment variables')
        self.config = {**self.DEFAULTS, **raw}
        if not isinstance(self.config.get('model'), str) or not self.config['model'].strip():
            raise ValueError('model config requires model')
        if self.config['model'].startswith('YOUR_'):
            raise ValueError('replace YOUR_MODEL with an available model name')
        parts = urllib.parse.urlparse(self.config['base_url'])
        if parts.username or parts.password or parts.query or parts.fragment or not parts.hostname:
            raise ValueError('base_url must be a plain API URL without credentials/query')
        if parts.scheme != 'https' and not (
            parts.scheme=='http' and parts.hostname in ('127.0.0.1','localhost','::1')):
            raise ValueError('use HTTPS, or HTTP only for a localhost inference server')
        for key in ('max_tokens','timeout','max_input_chars'):
            if type(self.config[key]) not in (int, float) or not math.isfinite(self.config[key]) or self.config[key]<=0:
                raise ValueError(f'{key} must be positive')
        if type(self.config['max_retries']) is not int or not 0<=self.config['max_retries']<=10:
            raise ValueError('max_retries must be 0..10')
        if self.config['token_parameter'] not in ('max_tokens','max_completion_tokens'):
            raise ValueError('unsupported token_parameter')
        if self.config['temperature'] is not None and (
            type(self.config['temperature']) not in (int,float) or
            not math.isfinite(self.config['temperature']) or not 0<=self.config['temperature']<=2):
            raise ValueError('temperature must be null or between 0 and 2')
        if type(self.config['retry_backoff']) not in (int,float) or not 0<=self.config['retry_backoff']<=30:
            raise ValueError('retry_backoff must be 0..30')
        self.url = self.config['base_url'].rstrip('/')+'/chat/completions'

    def public_config(self):
        return dict(self.config)

    def complete(self, messages, *, json_output=False):
        if len(json.dumps(messages, ensure_ascii=False)) > self.config['max_input_chars']:
            raise APIError('input exceeds max_input_chars; no automatic truncation was applied')
        payload = {'model':self.config['model'], 'messages':messages,
                   self.config['token_parameter']:self.config['max_tokens']}
        if self.config['temperature'] is not None:
            payload['temperature'] = self.config['temperature']
        if json_output and self.config['json_mode']:
            payload['response_format'] = {'type':'json_object'}
        headers = {'Content-Type':'application/json', 'User-Agent':'bipia-mix/1.0'}
        key_var = self.config['api_key_env']
        if key_var:
            key = self._api_key or os.environ.get(key_var)
            if not key:
                raise APIError(f'missing environment variable: {key_var}')
            headers['Authorization'] = 'Bearer '+key
        data = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode('utf-8')
        for attempt in range(self.config['max_retries']+1):
            wait = min(30, self.config['retry_backoff']*2**attempt)
            try:
                request = urllib.request.Request(self.url, data=data, headers=headers)
                with urllib.request.build_opener(NoRedirect).open(request, timeout=self.config['timeout']) as response:
                    raw = json.load(response)
                choices = raw.get('choices', [])
                if not choices:
                    raise APIError('API returned no choices')
                choice = choices[0]
                message = choice.get('message', {})
                text = message.get('content')
                response_type = 'text'
                if (not isinstance(text,str) or not text.strip()) and isinstance(message.get('refusal'),str) and message['refusal'].strip():
                    text = message['refusal']
                    response_type = 'refusal'
                if not isinstance(text, str) or not text.strip():
                    raise APIError('API returned empty/non-text content')
                return {'text':text, 'model_resolved':raw.get('model'),
                        'finish_reason':choice.get('finish_reason'),
                        'usage':raw.get('usage', {}), 'provider_id':raw.get('id'),
                        'response_type':response_type}
            except urllib.error.HTTPError as exc:
                retryable = exc.code in (408,409,429) or 500<=exc.code<600
                if not retryable or attempt == self.config['max_retries']:
                    # Never persist response bodies/headers which may echo credentials.
                    code = exc.code
                    exc.close()
                    raise APIError(f'HTTP {code} from model API') from None
                retry_after = exc.headers.get('Retry-After')
                if retry_after:
                    try: wait = min(30, max(wait, float(retry_after)))
                    except ValueError: pass
                exc.close()
            except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError):
                if attempt == self.config['max_retries']:
                    raise APIError('network/timeout error after bounded retries') from None
            except (json.JSONDecodeError, KeyError, TypeError, AttributeError):
                raise APIError('malformed model API response') from None
            if wait:
                time.sleep(wait)
        raise APIError('request did not complete')

    def complete_json(self, messages):
        reply = self.complete(messages, json_output=True)
        if reply['finish_reason']=='length':
            raise APIError('JSON response was truncated; raise model max_tokens')
        return parse_json_object(reply['text'])
