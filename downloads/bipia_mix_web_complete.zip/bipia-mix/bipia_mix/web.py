"""Loopback-only web console for the existing experiment engine.

Launch: python -m bipia_mix web. No model call occurs on startup.
"""
from __future__ import annotations

import io
import json
import mimetypes
import re
import threading
import time
import uuid
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .client import ChatClient
from .data import select_cases, build_study
from .variants import approve_variants, generate_variants
from .runner import run_study, latest_records
from .scoring import score_records
from .report import write_report
from .storage import read_json, read_jsonl, write_json, write_jsonl, file_hash

SEED_IDS=['Task Automation-2','Base Encoding-0','Language Translation-0']


class ExperimentApp:
    def __init__(self, root=None, runs=None):
        self.root=Path(root or Path(__file__).resolve().parents[1])
        self.runs=Path(runs or self.root/'runs'/'web')
        self.runs.mkdir(parents=True,exist_ok=True)
        self.assets=Path(__file__).parent/'web_ui'
        self.jobs={}
        self.mutex=threading.Lock()

    def bootstrap(self):
        return {'mode':'local','cases':select_cases(self.root/'data/bipia','email','test',6,2023,SEED_IDS),
                'variants':read_jsonl(self.root/'data/variants_seed.jsonl'),
                'stats':{'contexts':50,'attacks':75,'attack_types':15},
                'attack_ids':[f'{k}-{i}' for k,v in read_json(self.root/'data/bipia/benchmark/text_attack_test.json').items()
                              for i in range(len(v))]}

    def folder(self, identity):
        if not isinstance(identity,str) or not re.fullmatch(r'[a-f0-9]{32}',identity):
            raise ValueError('invalid experiment ID')
        path=self.runs/identity
        if not path.is_dir():raise ValueError('experiment not found')
        return path

    @staticmethod
    def client(payload):
        config=dict(payload.get('config') or {})
        return ChatClient(config,api_key=payload.get('api_key') or None)

    def start_job(self,kind,folder,action,expected=0):
        with self.mutex:
            if any(j['status']=='running' for j in self.jobs.values()):
                raise ValueError('another operation is running; wait for it to finish')
            job_id=uuid.uuid4().hex
            job={'job_id':job_id,'study_id':folder.name,'kind':kind,'status':'running',
                 'started_at':time.time(),'expected':expected,'completed':0}
            self.jobs[job_id]=job
        def work():
            try:
                result=action()
                with self.mutex:job.update(status='done',result=result,finished_at=time.time())
            except Exception as exc:
                from .client import APIError
                message=str(exc) if isinstance(exc,(ValueError,APIError,FileNotFoundError)) else type(exc).__name__
                with self.mutex:job.update(status='error',error=message,finished_at=time.time())
        threading.Thread(target=work,daemon=True).start()
        return {'job_id':job_id,'study_id':folder.name}

    def job_status(self,job_id):
        with self.mutex:
            if job_id not in self.jobs:raise ValueError('job not found')
            result=dict(self.jobs[job_id])
        folder=self.folder(result['study_id'])
        filename='responses.jsonl' if result['kind']=='run' else 'scores.jsonl'
        if result['kind'] in ('run','score'):
            try:
                records=latest_records(folder/filename)
                result['completed']=sum(r.get('status')=='ok' for r in records.values())
                result['errors']=sum(r.get('status')!='ok' for r in records.values())
            except ValueError:
                pass # A writer may be appending its single JSONL line at this moment.
        return result

    def post(self,path,payload):
        if path=='/api/select':
            count=int(payload.get('count',6))
            if not 1<=count<=300:raise ValueError('select between 1 and 300 cases in the web console')
            attacks=SEED_IDS if payload.get('attack_scope','seed')=='seed' else None
            return {'cases':select_cases(self.root/'data/bipia','email','test',count,
                                          int(payload.get('seed',2023)),attacks)}
        if path=='/api/approve':
            return {'variants':approve_variants(payload['variants'],str(payload.get('reviewer','')))}
        if path=='/api/build':
            study=build_study(payload['cases'],payload['variants'],seed=int(payload.get('seed',2023)),
                              positions=tuple(payload.get('positions',['start','middle','end'])),
                              layout=payload.get('layout','bipia-system'),defense=payload.get('defense','none'))
            identity=uuid.uuid4().hex;folder=self.runs/identity;folder.mkdir()
            write_jsonl(folder/'study.jsonl',study)
            write_json(folder/'meta.json',{'name':str(payload.get('name','Untitled experiment'))[:120],
                                          'created_at':time.time(),'study_id':identity})
            return {'study_id':identity,'samples':len(study),'attacked':sum(r['condition']!='clean' for r in study),
                    'clean':sum(r['condition']=='clean' for r in study)}
        if path=='/api/connect':
            result=self.client(payload).complete([{'role':'user','content':'Reply with only: connection successful.'}])
            return {'ok':True,'text':result['text'],'model':result.get('model_resolved')}
        if path=='/api/translate':
            folder=self.runs/uuid.uuid4().hex;folder.mkdir()
            client=self.client(payload);cases=payload['cases']
            def action():
                rows=generate_variants(cases,client,folder/'variants.draft.jsonl')
                return {'variants':rows}
            return self.start_job('translate',folder,action,len({c['attack_id'] for c in cases}))
        if path=='/api/run':
            folder=self.folder(payload['study_id']);study=read_jsonl(folder/'study.jsonl')
            client=self.client(payload);repeats=int(payload.get('repeats',1))
            if not 1<=repeats<=10:raise ValueError('repeats must be 1..10')
            budget=payload.get('max_requests')
            budget=None if budget is None else int(budget)
            def action():return run_study(study,client,folder/'responses.jsonl',repeats=repeats,
                                          max_requests=budget,workers=1)
            return self.start_job('run',folder,action,len(study)*repeats)
        if path=='/api/score':
            folder=self.folder(payload['study_id']);study=read_jsonl(folder/'study.jsonl')
            client=self.client(payload)
            if not (folder/'responses.jsonl').exists():raise ValueError('run the target model first')
            def action():
                score_records(study,folder/'responses.jsonl',folder/'scores.jsonl',client)
                report=write_report(study,folder/'responses.jsonl',folder/'scores.jsonl',folder/'report',bootstrap=1000)
                write_json(folder/'report/provenance.json',{'responses':file_hash(folder/'responses.jsonl'),'scores':file_hash(folder/'scores.jsonl')})
                return {'summary':report}
            return self.start_job('score',folder,action,len(latest_records(folder/'responses.jsonl')))
        raise ValueError('unknown API action')

    def results(self,identity):
        folder=self.folder(identity)
        result={'study_id':identity,'study':read_jsonl(folder/'study.jsonl')}
        for name in ('responses','scores'):
            result[name]=list(latest_records(folder/f'{name}.jsonl').values())
        path=folder/'report/summary.json'
        provenance=folder/'report/provenance.json'
        current=path.exists() and provenance.exists() and read_json(provenance)=={
            name:file_hash(folder/f'{name}.jsonl') for name in ('responses','scores') if (folder/f'{name}.jsonl').exists()}
        result['summary']=read_json(path) if current else None
        result['summary_stale']=path.exists() and not current
        return result

    def archive(self,identity):
        folder=self.folder(identity);buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
            for path in folder.rglob('*'):
                if path.is_file() and path.suffix not in ('.lock','.tmp'):
                    z.write(path,path.relative_to(folder))
        return buffer.getvalue()


def make_server(app,port=8765):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass

        def send(self,status,body,content_type='application/json; charset=utf-8',filename=None):
            if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
            self.end_headers();self.wfile.write(body)

        def allowed_host(self):
            return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')

        def do_GET(self):
            if not self.allowed_host():return self.send(403,{'error':'invalid Host header'})
            path=urlparse(self.path).path
            try:
                if path=='/api/status':
                    with app.mutex:active=next((dict(j) for j in app.jobs.values() if j['status']=='running'),None)
                    return self.send(200,{'mode':'local','engine':'bipia-mix','version':'1.2.0','active_job':active})
                if path=='/api/bootstrap':return self.send(200,app.bootstrap())
                if path.startswith('/api/jobs/'):
                    return self.send(200,app.job_status(path.rsplit('/',1)[-1]))
                if path.startswith('/api/results/'):
                    return self.send(200,app.results(path.rsplit('/',1)[-1]))
                if path.startswith('/api/download/'):
                    identity=path.rsplit('/',1)[-1]
                    return self.send(200,app.archive(identity),'application/zip','bipia-run.zip')
                if path=='/api/experiments':
                    return self.send(200,{'experiments':[read_json(p) for p in app.runs.glob('*/meta.json')]})
                filename='index.html' if path=='/' else path.lstrip('/')
                if filename not in ('index.html','app.mjs','core.mjs','i18n.mjs','styles.css','bootstrap.json','demo.json'):
                    return self.send(404,{'error':'not found'})
                content=(app.assets/filename).read_bytes()
                ctype={'mjs':'text/javascript','css':'text/css','html':'text/html','json':'application/json'}[filename.rsplit('.',1)[-1]]
                return self.send(200,content,ctype+'; charset=utf-8')
            except (ValueError,KeyError,OSError) as exc:return self.send(400,{'error':str(exc)})

        def do_POST(self):
            origin=self.headers.get('Origin')
            valid_origins=(f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}')
            if not self.allowed_host() or (origin is not None and origin not in valid_origins):
                return self.send(403,{'error':'foreign origin is not allowed'})
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':
                return self.send(415,{'error':'application/json required'})
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=12*1024*1024:return self.send(413,{'error':'invalid body size'})
                payload=json.loads(self.rfile.read(length))
                if not isinstance(payload,dict):raise ValueError('JSON object required')
                return self.send(200,app.post(urlparse(self.path).path,payload))
            except (ValueError,KeyError,OSError) as exc:return self.send(400,{'error':str(exc)})
            except Exception:return self.send(500,{'error':'operation failed; verify model configuration'})
    return ThreadingHTTPServer(('127.0.0.1',port),Handler)


def serve(port=8765,open_browser=True):
    app=ExperimentApp();server=make_server(app,port)
    url=f'http://127.0.0.1:{server.server_port}'
    print(f'BIPIA Lab: {url}\nModel keys stay in memory. Press Ctrl+C to stop.')
    if open_browser:threading.Timer(.4,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
