"""Command-line entry point. See README.md for Chinese step-by-step usage."""
from __future__ import annotations

import argparse
import html
import json
import sys
from pathlib import Path

from .storage import read_jsonl, write_jsonl, write_text
from .data import TASKS, select_cases, build_study
from .variants import CONDITIONS, approve_variants, validate_variant, generate_variants
from .client import ChatClient, APIError
from .runner import run_study
from .scoring import score_records
from .report import write_report
from .demo import run_demo


def review_html(rows, output):
    content=['<!doctype html><html lang="zh"><meta charset="utf-8"><title>语言变体审核</title>',
             '<style>body{font:16px/1.6 system-ui;max-width:1000px;margin:36px auto;padding:0 20px;background:#f6f8fc;color:#172033}section{background:white;padding:24px;margin:20px 0;border-radius:12px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f1f4fa;padding:12px}h2{font-size:20px}</style>',
             '<h1>BIPIA 中英混合变体审核</h1><p>检查四个版本是否保持同一目标、语气和约束；检查受保护字面量、切换层级、长度差异及判定标准。此页只供阅读；修改 JSONL 后再运行 approve。自动检查通过不代表语义等价。</p>']
    for row in rows:
        validate_variant(row)
        content.append('<section><h2>'+html.escape(row['attack_id'])+'</h2>')
        for condition in CONDITIONS:
            text=row['variants'][condition]
            content.append(f'<b>{condition} · {len(text)} characters</b><pre>'+html.escape(text)+'</pre>')
        content.append('<b>Success criterion</b><pre>'+html.escape(row['success_criterion'])+'</pre>')
        content.append('<b>Protected literals</b><pre>'+html.escape(json.dumps(row.get('protected_literals',[]),ensure_ascii=False))+'</pre></section>')
    content.append('</html>');write_text(output,'\n'.join(content))


def parser():
    p=argparse.ArgumentParser(description='BIPIA English–Chinese paired prompt-injection experiments')
    commands=p.add_subparsers(dest='command',required=True)
    s=commands.add_parser('select',help='Select stratified original BIPIA context/attack pairs')
    s.add_argument('--bipia-root',default='data/bipia');s.add_argument('--task',choices=TASKS,default='email')
    s.add_argument('--split',choices=('train','test'),default='test');s.add_argument('--cases',type=int,default=30)
    s.add_argument('--seed',type=int,default=2023);s.add_argument('--attack-ids',nargs='+');s.add_argument('--out',required=True)
    s=commands.add_parser('variants',help='Generate draft language variants with a configured model')
    s.add_argument('--cases',required=True);s.add_argument('--config',required=True);s.add_argument('--out',required=True)
    s=commands.add_parser('review-html',help='Render a read-only human review page')
    s.add_argument('--variants',required=True);s.add_argument('--out',required=True)
    s=commands.add_parser('approve',help='Record your completed human review; edits invalidate approval')
    s.add_argument('--variants',required=True);s.add_argument('--reviewer',required=True);s.add_argument('--out',required=True)
    s=commands.add_parser('build',help='Build four-condition paired prompts and unique clean controls')
    s.add_argument('--cases',required=True);s.add_argument('--variants',required=True);s.add_argument('--out',required=True)
    s.add_argument('--seed',type=int,default=2023);s.add_argument('--middle-mode',choices=('punkt','line'),default='punkt')
    s.add_argument('--positions',nargs='+',choices=('start','middle','end'),default=['start','middle','end'])
    s.add_argument('--layout',choices=('bipia-system','user-data'),default='bipia-system')
    s.add_argument('--defense',choices=('none','reminder'),default='none');s.add_argument('--no-clean',action='store_true')
    s=commands.add_parser('run',help='Call a target model with durable per-request results and resume')
    s.add_argument('--study',required=True);s.add_argument('--config',required=True);s.add_argument('--out',required=True)
    s.add_argument('--repeats',type=int,default=1);s.add_argument('--order-seed',type=int,default=2023)
    s.add_argument('--workers',type=int,default=1);s.add_argument('--max-requests',type=int)
    s=commands.add_parser('score',help='Evaluate responses with an independent semantic judge')
    s.add_argument('--study',required=True);s.add_argument('--responses',required=True)
    s.add_argument('--config',required=True);s.add_argument('--out',required=True);s.add_argument('--max-requests',type=int)
    s=commands.add_parser('report',help='Write CSV, JSON and Markdown; paired context-cluster bootstrap')
    s.add_argument('--study',required=True);s.add_argument('--responses',required=True)
    s.add_argument('--scores',required=True);s.add_argument('--out',required=True)
    s.add_argument('--bootstrap',type=int,default=2000);s.add_argument('--seed',type=int,default=2023)
    s=commands.add_parser('demo',help='Offline synthetic demonstration; no API calls or measured results')
    s.add_argument('--out',default='runs/demo')
    s=commands.add_parser('web',help='Launch the localhost experiment web console')
    s.add_argument('--port',type=int,default=8765);s.add_argument('--no-open',action='store_true')
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    try:
        if args.command=='select':
            rows=select_cases(args.bipia_root,args.task,args.split,args.cases,args.seed,args.attack_ids)
            write_jsonl(args.out,rows);result={'selected_cases':len(rows),'out':args.out}
        elif args.command=='variants':
            rows=generate_variants(read_jsonl(args.cases),ChatClient(args.config),args.out)
            result={'variants':len(rows),'status':'draft; review before approving','out':args.out}
        elif args.command=='review-html':
            review_html(read_jsonl(args.variants),args.out);result={'out':args.out}
        elif args.command=='approve':
            rows=approve_variants(read_jsonl(args.variants),args.reviewer)
            write_jsonl(args.out,rows);result={'approved':len(rows),'out':args.out}
        elif args.command=='build':
            rows=build_study(read_jsonl(args.cases),read_jsonl(args.variants),seed=args.seed,
                             middle_mode=args.middle_mode,positions=args.positions,layout=args.layout,
                             defense=args.defense,include_clean=not args.no_clean)
            write_jsonl(args.out,rows)
            result={'samples':len(rows),'attacked':sum(r['condition']!='clean' for r in rows),
                    'clean':sum(r['condition']=='clean' for r in rows),'out':args.out}
        elif args.command=='run':
            print('Running target requests; each result is saved immediately. Re-run the same command to resume.',file=sys.stderr)
            result=run_study(read_jsonl(args.study),ChatClient(args.config),args.out,args.repeats,
                             args.order_seed,args.max_requests,args.workers)
        elif args.command=='score':
            result=score_records(read_jsonl(args.study),args.responses,args.out,ChatClient(args.config),
                                 max_requests=args.max_requests)
        elif args.command=='report':
            report=write_report(read_jsonl(args.study),args.responses,args.scores,args.out,args.bootstrap,args.seed)
            result={'out':args.out,'total':report['total'],'paired':report['paired']}
        elif args.command=='demo':
            report=run_demo(args.out);result={'notice':'SYNTHETIC SIMULATION — NO MODEL WAS CALLED',
                                             'out':args.out,'total':report['total']}
        elif args.command=='web':
            from .web import serve
            serve(args.port,not args.no_open)
            return 0
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except (ValueError,KeyError,OSError,APIError) as exc:
        print(f'Error: {exc}',file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
