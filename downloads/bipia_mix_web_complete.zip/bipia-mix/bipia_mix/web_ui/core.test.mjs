import test from 'node:test';
import assert from 'node:assert/strict';
import {parseJSONL, canonical, approvedVariant, readiness, expectedCounts, resultRows,sha256,validateSummary} from './core.mjs';

test('JSONL import reports bad line and rejects nonobjects',()=>{
  assert.deepEqual(parseJSONL('{"x":1}\n'),[{x:1}]);
  assert.throws(()=>parseJSONL('{"x":1}\ninvalid'),/2/);
  assert.throws(()=>parseJSONL('[]'),/对象/);
});
test('canonical recursively orders keys like the Python digest input',()=>{
  assert.equal(canonical({b:2,a:{d:4,c:3}}),'{"a":{"c":3,"d":4},"b":2}');
});
test('four conditions and three positions use paired counts',()=>{
  const cases=[{task:'email',context_id:'a',question:'q',ideal:'x'},{task:'email',context_id:'a',question:'q',ideal:'x'}];
  assert.deepEqual(expectedCounts(cases,['start','end'],3),{attacked:16,clean:1,samples:17,requests:51});
});
test('review progress is based on used attack IDs only',()=>{
  const r=readiness({cases:[{attack_id:'A'}],variants:[{attack_id:'A',status:'draft'}],connected:false,studyId:null,hasResults:false});
  assert.equal(r.reviewed,0);assert.equal(r.required,1);assert.equal(r.ready,false);
});
test('approval digest matches Python canonical hashing',async()=>{
  const v={attack_id:'A',original:'Hello',variants:{en:'Hello',zh:'你好',mixed_sentence:'Hello，你好。',mixed_phrase:'请 say hello。'},success_criterion:'Greeting',protected_literals:[],evaluation:{kind:'semantic'},status:'draft'};
  const approved=await approvedVariant(v,'R');
  assert.equal(approved.status,'approved');assert.equal(approved.review.digest.length,64);
  assert.ok(!canonical(approved).includes('api_key'));
});
test('result rows join by sample IDs, never by completion order',()=>{
  const rows=resultRows([{sample_id:'a',condition:'en'},{sample_id:'b',condition:'zh'}],
    [{sample_id:'b',job_id:'b:0',text:'second',status:'ok'},{sample_id:'a',job_id:'a:0',text:'first',status:'ok'}],[]);
  assert.equal(rows[0].condition,'zh');assert.equal(rows[1].condition,'en');
});

test('SHA-256 works without secure-context Web Crypto',async()=>{
  assert.equal(await sha256('abc',null),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  assert.equal(await sha256('中文',null),'72726d8818f693066ceb69afa364218b692e62ea92b385782363780f47529c21');
});

test('summary import rejects injected counts and malformed paired values',()=>{
 assert.throws(()=>validateSummary({groups:[],paired:[{n_complete_pairs:'<img src=x onerror=alert(1)>'}]}),/汇总/);
 assert.throws(()=>validateSummary({groups:[{condition:'en',asr:0.5,expected:'bad'}]}),/汇总/);
 assert.deepEqual(validateSummary({groups:[],paired:[]}),{groups:[],paired:[]});
});
