"""Valid-denominator ASR and paired context-cluster bootstrap reports."""
from __future__ import annotations

import csv
import io
import random
from collections import defaultdict
from pathlib import Path

from .storage import digest, read_json, read_jsonl, write_json, write_text, unique_index
from .runner import validate_study, latest_records
from .variants import CONDITIONS


def _mean(values):
    return sum(values)/len(values) if values else None


def _ci(clusters, iterations, seed):
    if len(clusters)<2 or iterations<1:
        return None
    rng = random.Random(seed)
    groups = list(clusters.values())
    draws = []
    for _ in range(iterations):
        chosen = [groups[rng.randrange(len(groups))] for _ in groups]
        draws.append(sum(sum(g) for g in chosen)/sum(len(g) for g in chosen))
    draws.sort()
    return [draws[int((len(draws)-1)*.025)], draws[int((len(draws)-1)*.975)]]


def summarize(study, responses, scores, repeats=1, bootstrap=2000, seed=2023):
    validate_study(study)
    if repeats<1 or bootstrap<0:
        raise ValueError('invalid repeats/bootstrap')
    response_index = {r['job_id']:r for r in responses}
    score_index = {r['job_id']:r for r in scores}
    expected = {f'{row["sample_id"]}:{rep}' for row in study for rep in range(repeats)}
    if set(response_index)-expected or set(score_index)-expected:
        raise ValueError('unexpected request IDs in results')
    groups, positions = {}, {}
    pairs = defaultdict(dict)
    technical_fields = ('missing_generation','generation_error','truncated','filtered','incomplete',
                        'missing_score','scoring_error','stale_score')

    def new_group(row, position=False):
        out = {k:row[k] for k in ('task','condition','layout','defense')}
        if position: out['position']=row['position']
        out.update(expected=0, attack_successes=0, valid_attack_scores=0,
                   unknown_attack_scores=0, task_correct=0, valid_task_scores=0,
                   unknown_task_scores=0, **{k:0 for k in technical_fields})
        out['_clusters'] = defaultdict(list)
        return out

    for row in study:
        key = tuple(row[k] for k in ('task','condition','layout','defense'))
        group=groups.setdefault(key,new_group(row))
        poskey=key+(row['position'],)
        posgroup=positions.setdefault(poskey,new_group(row,True))
        for rep in range(repeats):
            job=f'{row["sample_id"]}:{rep}'
            response=response_index.get(job)
            score=score_index.get(job)
            targets=(group,posgroup)
            for g in targets:g['expected']+=1
            problem=None
            if response is None: problem='missing_generation'
            elif response.get('status')=='truncated': problem='truncated'
            elif response.get('status')=='filtered': problem='filtered'
            elif response.get('status')=='incomplete': problem='incomplete'
            elif response.get('status')!='ok': problem='generation_error'
            elif score is None: problem='missing_score'
            elif score.get('response_digest')!=digest(response): problem='stale_score'
            elif score.get('status')!='ok': problem='scoring_error'
            if problem:
                for g in targets:g[problem]+=1
                continue
            attack=score.get('attack_success')
            correct=score.get('task_correct')
            for g in targets:
                if type(correct) is bool:
                    g['valid_task_scores']+=1;g['task_correct']+=int(correct)
                else:g['unknown_task_scores']+=1
                if row['condition']!='clean':
                    if type(attack) is bool:
                        g['valid_attack_scores']+=1;g['attack_successes']+=int(attack)
                        g['_clusters'][row['context_id']].append(int(attack))
                    else:g['unknown_attack_scores']+=1
            if row['condition']!='clean' and type(attack) is bool:
                pairkey=(row['case_id'],row['position'],rep,row['layout'],row['defense'])
                pairs[pairkey][row['condition']]=(int(attack),row['context_id'])

    def finish(g):
        clusters=g.pop('_clusters')
        g['asr']=g['attack_successes']/g['valid_attack_scores'] if g['valid_attack_scores'] else None
        g['task_accuracy']=g['task_correct']/g['valid_task_scores'] if g['valid_task_scores'] else None
        g['n_context_clusters']=len(clusters)
        g['asr_cluster_ci95']=_ci(clusters,bootstrap,seed)
        g['attack_score_coverage']=g['valid_attack_scores']/g['expected'] if g['condition']!='clean' else None
        return g

    main=[finish(g) for _,g in sorted(groups.items())]
    by_position=[finish(g) for _,g in sorted(positions.items())]
    comparisons=[]
    complete=[p for p in pairs.values() if set(p)==set(CONDITIONS)]
    for condition in CONDITIONS[1:]:
        clusters=defaultdict(list);differences=[]
        for pair in complete:
            delta=pair[condition][0]-pair['en'][0]
            differences.append(delta);clusters[pair['en'][1]].append(delta)
        comparisons.append({'condition':condition,'baseline':'en',
                            'n_complete_pairs':len(complete),'n_context_clusters':len(clusters),
                            'delta_asr_vs_en':_mean(differences),
                            'cluster_bootstrap_ci95':_ci(clusters,bootstrap,seed)})
    total={key:sum(g[key] for g in main) for key in ('expected',)+technical_fields}
    return {'schema':1,'corpus_kinds':sorted({r['corpus_kind'] for r in study}),
            'total':total,'groups':main,'by_position':by_position,'paired':comparisons,
            'statistics':{'bootstrap_iterations':bootstrap,'seed':seed,
                          'cluster_unit':'context_id','paired_units':'case_id + position + repeat; complete four-condition sets only',
                          'note':'CI is omitted with fewer than two context clusters. Small-cluster intervals are exploratory. Errors and unknown judgments are excluded, with coverage reported. This is a BIPIA-derived language study, not the original evaluator.'}}


def write_report(study, responses_path, scores_path, output_dir, bootstrap=2000, seed=2023):
    inference=read_json(str(responses_path)+'.manifest.json')
    scoring=read_json(str(scores_path)+'.manifest.json')
    if inference.get('study_digest')!=digest(study) or scoring.get('study_digest')!=digest(study):
        raise ValueError('report manifest/study mismatch')
    if scoring.get('inference_run_id')!=digest(inference):
        raise ValueError('scores belong to a different inference run')
    responses=list(latest_records(responses_path,digest(inference)).values())
    scores=list(latest_records(scores_path,digest(scoring)).values())
    report=summarize(study,responses,scores,repeats=inference['repeats'],bootstrap=bootstrap,seed=seed)
    report['inference_manifest']=inference
    report['scoring_manifest']=scoring
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    write_json(out/'summary.json',report)
    for filename, rows in [('summary.csv',report['groups']),('positions.csv',report['by_position']),('paired.csv',report['paired'])]:
        buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=list(rows[0]) if rows else [])
        writer.writeheader();writer.writerows(rows);write_text(out/filename,buffer.getvalue())
    lines=['# BIPIA Mix results', '', '**OFFLINE SYNTHETIC DEMO — NOT EMPIRICAL RESULTS**' if report['corpus_kinds']==['synthetic'] else 'BIPIA-derived paired language experiment.', '',
           '| Task | Condition | Valid / expected | ASR | Task accuracy |',
           '|---|---|---:|---:|---:|']
    fmt=lambda v:'NA' if v is None else f'{v:.3f}'
    for g in report['groups']:
        valid=g['valid_task_scores'] if g['condition']=='clean' else g['valid_attack_scores']
        lines.append(f'| {g["task"]} | {g["condition"]} | {valid}/{g["expected"]} | {fmt(g["asr"])} | {fmt(g["task_accuracy"])} |')
    lines+=['','Paired delta = condition ASR minus English ASR. Only complete four-language sets are included.',
            'Bootstrap resamples original contexts, keeping positions/variants/repeats together.',
            'Missing generations, truncation, errors, unknowns and stale scores are counted in summary.json.',
            'Low coverage may bias ASR; do not interpret missing responses as attack failures.','']
    write_text(out/'report.md','\n'.join(lines))
    return report
