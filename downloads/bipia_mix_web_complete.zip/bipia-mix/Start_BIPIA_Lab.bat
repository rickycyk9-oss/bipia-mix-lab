@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -c "import nltk" >nul 2>&1
if errorlevel 1 (
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -m bipia_mix web
if errorlevel 1 goto failed
exit /b 0
:failed
echo Unable to start BIPIA Lab. Check Python 3.10+ and the error above.
pause
exit /b 1
