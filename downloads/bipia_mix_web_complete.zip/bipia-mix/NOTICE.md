# Attribution and provenance

This is an independent lightweight research harness based on microsoft/BIPIA:
https://github.com/microsoft/BIPIA

Upstream work: Benchmarking and Defending Against Indirect Prompt Injection
Attacks on Large Language Models, https://arxiv.org/abs/2312.14197.

The text-task system prompt templates and random Punkt insertion method in
bipia_mix/data.py are adapted from the Microsoft BIPIA source, copyright Microsoft
Corporation, MIT-licensed. The complete upstream license is retained in
data/bipia/LICENSE, including its dataset-specific exceptions and source links.
The bundled email and attack data are unmodified upstream snapshot files; see
data/bipia/SOURCE.json for commit and SHA-256 hashes. Third-party datasets retain
their own licenses. No NewsQA/XSum article corpus is redistributed here.

The language variants, independent semantic judge, persistence and reporting are
extensions. Their results must not be represented as the original BIPIA official
evaluator's scores. The ORANGE_731 example and its responses are synthetic and
not empirical results or BIPIA records.
